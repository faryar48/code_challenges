Rails.application.routes.default_url_options = {
  host: 'localhost',
  port: 3000
}
