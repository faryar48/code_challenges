# require '../config/environment'

# require 'twilio-ruby'

# account_sid = 'AC2196f578c57d20ddea1a2756c816badf'
# auth_token = 'b61397ee32413afb7a1558aa28248c6f'

# # set up a client to talk to the Twilio REST API
# @client = Twilio::REST::Client.new account_sid, auth_token

# @client.account.messages.create({
#   :from => '+15005550006',
#   :to => '+18055515746',
#   :body => 'hey there ',
# })