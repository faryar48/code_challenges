class MessageCreator
  attr_accessor :message, :sms_record

  def initialize(params)
    @message = Message.new(allowed_params(params))
  end

  def ok?
    save_message && send_notification
  end

  private

  def send_notification
    if message.recipient_email
      MessageMailer.secure_message(@message).deliver_now
      return true
    end
    if message.recipient_phone
      @sms_record = MessageTexter.send_secure_message(@message)
      return true
    end
  end

  def save_message
    @message.secure_id = SecureRandom.urlsafe_base64(25)
    @message.save
  end

  def allowed_params(params)
    {
      sender_email: (params[:sender] if is_email?(params[:sender])),
      sender_phone: (params[:sender] if not is_email?(params[:sender])),
      recipient_email: (params[:recipient] if is_email?(params[:recipient])),
      recipient_phone: (params[:recipient] if not is_email?(params[:recipient])),
      body: params[:body]
    }
  end

  def is_email?(str)
    str && str.include?("@")
  end
end










