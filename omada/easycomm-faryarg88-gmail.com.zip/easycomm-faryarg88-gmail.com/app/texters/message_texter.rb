class MessageTexter
  def self.send_secure_message(message)
    @message = message
    twilio_account_sid = ENV['TWILIO_ACCOUNT_SID']
    twilio_auth_token = ENV['TWILIO_AUTH_TOKEN']
    binding.pry
    @client = Twilio::REST::Client.new twilio_account_sid, twilio_auth_token
    env_domain = Rails.application.config.action_mailer.smtp_settings[:domain]
    @client.account.messages.create(:body => "Secure Message from #{message.sender}. You can access your message at #{env_domain}pickups/#{message.secure_id}",
        :to => message.recipient,
        :from => message.sender)
  end
end
